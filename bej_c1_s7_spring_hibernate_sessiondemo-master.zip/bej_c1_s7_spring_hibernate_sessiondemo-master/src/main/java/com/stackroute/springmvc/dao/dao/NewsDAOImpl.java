package com.stackroute.springmvc.dao.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.stackroute.springmvc.dao.model.News;

@Repository
@Transactional
public class NewsDAOImpl implements INewsDAO 
{

	@Autowired
	private SessionFactory sessionFactory;
	
	
	@Override
	public boolean saveNews(News news) 
	{
		try
		{
			this.sessionFactory.getCurrentSession().save(news);
			return true;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public List<News> getAllNews() 
	{
		return this.sessionFactory.getCurrentSession().createQuery("from News").list();
	}

	@Override
	public boolean deleteNews(int newsId) 
	{
		try
		{
			News nobj = this.sessionFactory.getCurrentSession().load(News.class, newsId);
			this.sessionFactory.getCurrentSession().delete(nobj);
			return true;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return false;
		}
	}
}
