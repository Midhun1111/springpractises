package com.stackroute.springmvc.dao.dao;

import java.util.List;

import com.stackroute.springmvc.dao.model.News;

public interface INewsDAO 
{
	public boolean saveNews(News news);
	
	public List<News> getAllNews();
	
	public boolean deleteNews(int newsId);

}
