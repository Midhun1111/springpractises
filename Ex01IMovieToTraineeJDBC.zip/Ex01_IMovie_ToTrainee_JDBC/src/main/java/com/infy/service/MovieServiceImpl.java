package com.infy.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.dao.MovieDAO;
import com.infy.model.Movie;



@Service(value = "movieService")
public class MovieServiceImpl implements MovieService {

	@Autowired
	private MovieDAO movieDao;
	/**
	 This method first calls findMovie method of MovieDAOImpl passing movieId from Movie object received in parameter,
	 then calls addMovie method of MovieDAOImpl passing Movie object received in parameter
	 @param Movie object
	 @return String movieId received from  addMovie method of MovieDAOImpl
	 @throws Service.MOVIE_AVAILABLE exception if Movie object returned by findMovie method of MovieDAOImpl is not null
	 */
	@Override
	public String addMovie(Movie movie) throws Exception {
		Movie mov = movieDao.findMovie(movie.getMovieId());
		if (mov!=null) {
			throw new Exception("Service.MOVIE_AVAILABLE");
		}
		String movieId = movieDao.addMovie(movie);
		return movieId;
	}
	/**
	 This method  calls getMovies method of MovieDAOImpl passing year  received in parameter
	
	 @param Integer year
	 @return List<Movie> received from  getMovies method of MovieDAOImpl
	 @throws Service.NO_MOVIE_RELEASED exception if Movie List returned by getMovies method of MovieDAOImpl is empty
	 */
	@Override
	public List<Movie> getMovies(Integer year) throws Exception {
		List<Movie> movies = movieDao.getMovies(year);
		if(movies.size()==0)
			throw new Exception("Service.NO_MOVIE_RELEASED");
		return movies;
	}
	/**
	 This method first calls findMovie method of MovieDAOImpl passing movieId received in parameter,
	 then calls updateRevenue method of MovieDAOImpl passing movieId and amount received in parameter
	 @param String movieId, Integer amount
	
	 @throws Service.MOVIE_UNAVAILABLE exception if Movie object returned by findMovie method of MovieDAOImpl is  null
	 */
	@Override
	public void updateRevenue(String movieId, Integer amount) throws Exception {
		Movie mov = movieDao.findMovie(movieId);
		if (mov==null) {
			throw new Exception("Service.MOVIE_UNAVAILABLE");
		}
		movieDao.updateRevenue(movieId,amount);
	}
	/**
	 This method first calls findMovie method of MovieDAOImpl passing movieId received in parameter,
	 then calls deleteMovie method of MovieDAOImpl passing movieId received in parameter
	 @param String movieId
	
	 @throws Service.MOVIE_UNAVAILABLE exception if Movie object returned by findMovie method of MovieDAOImpl is  null
	 */
	@Override
	public void deleteMovie(String movieId) throws Exception {
		Movie mov = movieDao.findMovie(movieId);
		if (mov==null) {
			throw new Exception("Service.MOVIE_UNAVAILABLE");
		}
		movieDao.deleteMovie(movieId);
	}
}