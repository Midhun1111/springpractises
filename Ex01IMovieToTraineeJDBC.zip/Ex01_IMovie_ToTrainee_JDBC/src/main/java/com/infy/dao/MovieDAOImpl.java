package com.infy.dao;

import java.util.List;


import com.infy.model.Movie;

public class MovieDAOImpl implements MovieDAO {
	

	/**
	 This method will find whether the given movieId is available in the database or not
	 @param - String movieId
	 @return - Movie object that contains movie details of the given movieId 
	    
	 */
	@Override
	public Movie findMovie(String movieId) throws Exception {
		return null;
	}

	/**
	 This method will add the details of the given movie into the database
	  @param - Movie object  details to be added to the database
	  @return - String movieId of the movie that was added into database
	 */
	@Override
	public String addMovie(Movie movie) throws Exception {
		return null;
	}
	/**
	 This method will get all the details of Movie for given year from the database
	  @param - Integer year 
	  @return - List<Movie> fetched from database for given year
	 */
	@Override
	public List<Movie> getMovies(Integer year) throws Exception {
		return null;
	}
	/**
	 This method will update the amount of the given movieId with new amount received in parameter
	 @param - String movieId, Integer amount
	 */
	@Override
	public void updateRevenue(String movieId, Integer amount) throws Exception {

	}
	/**
	  this method will delete the details of the given movieId from the database
	  @param - String movieId
	 */
	@Override
	public void deleteMovie(String movieId) throws Exception {
	
	}

}