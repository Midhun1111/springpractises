package com.infy.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.infy.model.Movie;

public class MovieRowMapper implements RowMapper<Movie>{

	@Override
	public Movie mapRow(ResultSet rs, int arg1) throws SQLException{
		return null;
	}

}
