package com.infy.dao;

import java.util.List;

import com.infy.model.Movie;

public interface MovieDAO {

	public Movie findMovie(String movieId) throws Exception;

	public String addMovie(Movie movie) throws Exception;

	public List<Movie> getMovies(Integer year) throws Exception;

	public void updateRevenue(String movieId,Integer amount) throws Exception;

	public void deleteMovie(String movieId) throws Exception;

}
