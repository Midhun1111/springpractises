package com.infy;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.core.env.Environment;

import com.infy.model.Movie;
import com.infy.service.MovieService;

@SpringBootApplication
public class Ex01IMovieToTraineeApplication implements CommandLineRunner {

	@Autowired
	Environment environment;

	@Autowired
	MovieService service;

	public static void main(String[] args) {
		SpringApplication.run(Ex01IMovieToTraineeApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

		addMovie();
//		getMovies();
//		updateRevenue();
//		deleteMovie();

	}

	public void addMovie() {
		try {

			Movie movie = new Movie();

			movie.setMovieId("M1006");
			movie.setMovieName("The Terminator");
			movie.setLanguage("English");
			movie.setReleaseYear(1984);
			;
			movie.setRevenue(87000000);

			String movieId = service.addMovie(movie);
			
			System.out.print(environment.getProperty("UserInterface.INSERT_SUCCESS")+movieId);
			

		} catch (Exception e) {
			System.out
					.println(environment.getProperty(e.getMessage(), "Some error has occured. Please check log file."));

		}
	}

	public void getMovies() {
		try {

			List<Movie> movies = service.getMovies(1987);
			System.out.println("Movie Id       Movie Name       Language		Release Year		Revenue ");
			System.out.println("-------------------------------------------------------------------------------");
			for (Movie movie : movies) {
				System.out.println(
						movie.getMovieId() + "\t\t" + movie.getMovieName() + "\t\t" + movie.getLanguage()
								+ "\t\t" + movie.getReleaseYear() + "\t\t" + movie.getRevenue());
			}
		} catch (Exception e) {
			System.out
					.println(environment.getProperty(e.getMessage(), "Some error has occured. Please check log file."));
		}
	}

	public void updateRevenue() {
		try {

			service.updateRevenue("M1006",4000);

			System.out.print(environment.getProperty("UserInterface.UPDATE_SUCCESS"));
			System.out.println();

		} catch (Exception e) {
			System.out
					.println(environment.getProperty(e.getMessage(), "Some error has occured. Please check log file."));

		}
	}

	public void deleteMovie() {
		try {

			service.deleteMovie("M1001");

			System.out.print(environment.getProperty("UserInterface.DELETE_SUCCESS"));

		} catch (Exception e) {
			System.out
					.println(environment.getProperty(e.getMessage(), "Some error has occured. Please check log file."));

		}
	}

}
