drop database if exists movie_db;
create database movie_db;
use  movie_db;



create table movie (
movieid varchar(6)  primary key,
moviename varchar(15)  not null,
language varchar(10)  not null,
releasedin int  not null,
revenueindollars int  not null
);



insert into movie values('M1001', 'Home Alone', 'English', 1990, 476700000);
insert into movie values('M1002', 'Home Alone', 'English', 1992, 358900000);
insert into movie values('M1003','Matrix','English',1994, 16800000);

commit;
select * from movie;

