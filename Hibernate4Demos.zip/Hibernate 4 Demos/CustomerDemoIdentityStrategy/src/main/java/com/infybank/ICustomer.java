package com.infybank;

public interface ICustomer {
	public void addCustomer(Customer c);
}
