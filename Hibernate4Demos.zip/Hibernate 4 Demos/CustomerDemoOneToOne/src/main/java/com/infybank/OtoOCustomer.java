package com.infybank;

public interface OtoOCustomer {
	public void addNewCustomerNewLocker(Customer c1,Locker l1);
	public void addNewCustomerNoLocker(Customer c1);

}
