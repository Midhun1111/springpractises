export MYSQL_USERNAME=root
export MYSQL_PASSWORD=root
export MYSQL_URL=jdbc:mysql://localhost:3306/registered_users?useSSL=false&createDatabaseIfNotExist=true&allowPublicKeyRetrieval=true