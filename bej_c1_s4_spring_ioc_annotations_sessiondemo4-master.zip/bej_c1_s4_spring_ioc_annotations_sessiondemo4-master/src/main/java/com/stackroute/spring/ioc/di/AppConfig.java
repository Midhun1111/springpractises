package com.stackroute.spring.ioc.di;

import org.springframework.context.annotation.Bean;


public class AppConfig
{
	
	@Bean("User1")
	public User getUser1()
	{
		return new User(1,"Kantha","one@12345");
	}
	
	@Bean("User2")
	public User getUser2()
	{
		return new User(2,"Sam","not#12345");

	}
	@Bean("address1")
	public Address getAddress()
	{
		return new Address(10,"darl street","delhi",110010);
	}
}
