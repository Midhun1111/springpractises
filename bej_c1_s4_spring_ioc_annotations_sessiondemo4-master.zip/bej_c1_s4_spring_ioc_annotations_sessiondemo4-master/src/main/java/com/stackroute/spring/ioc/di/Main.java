package com.stackroute.spring.ioc.di;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Main 
{
	public static void main(String[] aa)
	{
		AnnotationConfigApplicationContext context = 
				new AnnotationConfigApplicationContext(AppConfig.class);
		User user = context.getBean("User1",User.class);
		Address addr = context.getBean(Address.class);
		System.out.println(user);
		System.out.println(addr);

	}
}
