package com.stackroute.example;

import com.stackroute.example.config.AppConfig;
import com.stackroute.example.domain.User;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;


public class App 
{
    public static void main( String[] args )
    {
        AnnotationConfigApplicationContext annotationConfigApplicationContext =new AnnotationConfigApplicationContext(AppConfig.class);
        User user1 = (User) annotationConfigApplicationContext.getBean("user", User.class);
        System.out.println(user1.getEmail()+"::"+ user1.getName());
        System.out.println(user1.getAddress().getCity());

    }
}
