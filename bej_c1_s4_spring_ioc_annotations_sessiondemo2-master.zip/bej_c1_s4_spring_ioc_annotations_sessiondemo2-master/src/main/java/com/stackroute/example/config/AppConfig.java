package com.stackroute.example.config;

import com.stackroute.example.domain.Address;
import com.stackroute.example.domain.User;
import org.springframework.context.annotation.Bean;


public class AppConfig {
    @Bean("user")
    public User getCustomer()
    {
        User cust =  new User();
        cust.setCustomerId(1);
        cust.setName("Tony");
        cust.setEmail("tony@123.com");
        return cust;
    }

    @Bean
    public Address getAddress(){
        return new Address(10,"darl street","delhi",110010);
    }


}
